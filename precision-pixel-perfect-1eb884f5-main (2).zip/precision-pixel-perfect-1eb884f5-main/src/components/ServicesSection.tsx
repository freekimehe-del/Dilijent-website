import { Button } from '@/components/ui/button';
import serviceIt from '@/assets/service-it.jpg';
import serviceRcm from '@/assets/service-rcm.jpg';
import serviceMarketing from '@/assets/service-marketing.jpg';

const services = [
  {
    title: 'Information Technology Solutions',
    description: 'We provide innovative IT solutions that empower your business to operate smarter and faster. From advanced software development to seamless system integration, our services are designed to enhance efficiency, reduce downtime, and give you a competitive edge in today\'s technology-driven world.',
    image: serviceIt,
  },
  {
    title: 'Revenue Cycle Management',
    description: 'Maximize your revenue and streamline financial operations with our comprehensive revenue cycle management solutions. We handle everything from billing and collections to reporting, helping your business improve cash flow, reduce errors, and maintain compliance—all while boosting overall profitability.',
    image: serviceRcm,
  },
  {
    title: 'Digital Marketing Services',
    description: 'Grow your brand and reach your audience with our result-oriented digital marketing strategies. We specialize in SEO, social media marketing, PPC campaigns, and content marketing that not only increase visibility but also drive meaningful engagement and measurable business growth.',
    image: serviceMarketing,
  },
];

const ServicesSection = () => {
  return (
    <section id="services" className="py-20 bg-section-alt">
      <div className="container-custom">
        <div className="text-center mb-12">
          <p className="section-title">OUR SERVICES</p>
          <h2 className="section-heading">
            OUR CORE PROFESSIONAL <span className="text-primary">SERVICES</span>
          </h2>
          <p className="text-muted-foreground mt-4 max-w-3xl mx-auto">
            Our services span IT Solutions, Revenue Cycle Management, and Digital Marketing. For each domain, we deliver comprehensive solutions using the latest technologies and tools, designed to meet your business needs today and in the future.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-card rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 group"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-header/80 to-transparent" />
                <h3 className="absolute bottom-4 left-4 right-4 text-primary-foreground font-heading font-semibold text-lg">
                  {service.title}
                </h3>
              </div>
              <div className="p-6">
                <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                  {service.description}
                </p>
                <Button variant="default" className="w-full">
                  Read More
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
