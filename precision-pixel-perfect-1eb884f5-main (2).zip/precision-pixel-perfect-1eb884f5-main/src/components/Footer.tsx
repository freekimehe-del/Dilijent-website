import { Phone, Mail, MapPin } from 'lucide-react';
import logo from '@/assets/logo.png';

const Footer = () => {
  const quickLinks = [
    'Home', 'About Us', 'Blogs', 'Career', 'Privacy', 'Terms', 'Contact Us'
  ];

  const rcmServices = [
    'Revenue Cycle Management', 'Medical Billing Services', 'Medical Coding Services',
    'Medical Transcription Services', 'Medical Billing Audit', 'Account Receivable Management',
    'Home Health Agency Billing', 'Pharmacy Consulting Services', 'Design & Digital Solutions'
  ];

  const itServices = [
    'Software Development Services', 'Mobile App Development', 'Cloud Consulting Services',
    'Web Applications', 'Business Intelligence', 'Web Development',
    'E-Commerce Development', 'Robotic Automation', 'Beitech Software'
  ];

  return (
    <footer className="bg-header text-primary-foreground">
      <div className="container-custom py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="mb-4">
              <img src={logo} alt="Dilijent Systems" className="h-10" />
            </div>
            <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
              Dilijent Systems is a full-service IT, Revenue 
              Cycle Management Services and Digital 
              Solutions company that provides bespoke 
              solutions combined with cutting-edge 
              technology and mind-blowing in-house ideas to 
              convert your thoughts into appealing visuals.
            </p>
            <div className="space-y-3 text-sm">
              <a href="tel:+15125754630" className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
                <Phone size={14} />
                <span>+ 1 (512) -575-4630</span>
              </a>
              <a href="mailto:sales@dilijentsystems.com" className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
                <Mail size={14} />
                <span>sales@dilijentsystems.com</span>
              </a>
              <div className="flex items-start gap-2 text-muted-foreground">
                <MapPin size={14} className="mt-1 flex-shrink-0" />
                <span>5900 Balcones Drive, STE 14634 Austin, TX 78731</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-4">QUICK LINKS</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link}>
                  <a href="#" className="text-muted-foreground text-sm hover:text-primary transition-colors">
                    &gt; {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* RCM Services */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-4">OUR SERVICES</h4>
            <ul className="space-y-2">
              {rcmServices.map((service) => (
                <li key={service}>
                  <a href="#" className="text-muted-foreground text-sm hover:text-primary transition-colors">
                    &gt; {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* IT Services */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-4">&nbsp;</h4>
            <ul className="space-y-2">
              {itServices.map((service) => (
                <li key={service}>
                  <a href="#" className="text-muted-foreground text-sm hover:text-primary transition-colors">
                    &gt; {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-border/20 py-4">
        <div className="container-custom flex flex-col md:flex-row justify-between items-center text-sm text-muted-foreground">
          <p>Copyright © 2025. All rights reserved by <a href="#" className="text-primary hover:underline">Dilijent Systems</a></p>
          <div className="flex items-center gap-2 mt-2 md:mt-0">
            <span className="text-xs">Google Partner</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
