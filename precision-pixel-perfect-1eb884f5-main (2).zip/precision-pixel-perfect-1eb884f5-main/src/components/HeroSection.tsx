import { Button } from '@/components/ui/button';
import { Monitor, FileText } from 'lucide-react';
import heroBg from '@/assets/hero-bg.jpg';

const HeroSection = () => {
  return (
    <section id="home" className="relative min-h-[600px] flex items-center justify-center">
      {/* Background image with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center grayscale"
        style={{ backgroundImage: `url(${heroBg})` }}
      >
        <div className="absolute inset-0 bg-header/85" />
      </div>

      {/* Decorative curved shape */}
      <div className="absolute right-0 top-0 bottom-0 w-1/2 overflow-hidden pointer-events-none">
        <svg 
          className="absolute right-0 h-full opacity-10" 
          viewBox="0 0 400 600" 
          fill="none"
        >
          <path 
            d="M200 0 Q400 150 300 300 Q200 450 400 600" 
            stroke="hsl(var(--primary))" 
            strokeWidth="2" 
            fill="none"
          />
          <circle cx="350" cy="100" r="80" stroke="hsl(var(--primary))" strokeWidth="1" fill="none" opacity="0.3" />
        </svg>
      </div>

      {/* Content */}
      <div className="relative z-10 container-custom text-center py-16">
        <h1 className="font-heading text-4xl md:text-5xl lg:text-[3.5rem] font-semibold mb-4 leading-tight tracking-wide">
          <span className="text-primary italic">TECHNOLOGY </span>
          <span className="text-white">BUILT RIGHT.</span>
          <br />
          <span className="text-white">HEALTHCARE </span>
          <span className="text-primary">RCM </span>
          <span className="text-white">DONE BETTER.</span>
        </h1>
        
        <p className="text-gray-400 text-lg mb-10 font-body">
          Our Expertise Stands on Two Proven Pillars.
        </p>

        {/* Service boxes */}
        <div className="flex flex-col md:flex-row justify-center gap-4 max-w-5xl mx-auto">
          {/* Software Development Box */}
          <div className="flex-1 bg-header/90 backdrop-blur-sm rounded-lg p-6 md:p-8">
            <div className="w-14 h-14 bg-blue-500/10 border border-blue-500/50 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Monitor className="text-blue-500" size={28} />
            </div>
            <h3 className="text-white font-heading font-semibold text-lg mb-1">Software Development Services</h3>
            <p className="text-gray-400 text-sm mb-5 font-body">Custom App | AI/ML | Cloud</p>
            <Button variant="hero" className="w-full text-sm font-semibold font-heading">
              Get Quote for Software Dev.
            </Button>
          </div>

          {/* Medical Billing Box */}
          <div className="flex-1 bg-header/90 backdrop-blur-sm rounded-lg p-6 md:p-8">
            <div className="w-14 h-14 bg-blue-500/10 border border-blue-500/50 rounded-lg flex items-center justify-center mx-auto mb-4">
              <FileText className="text-blue-500" size={28} />
            </div>
            <h3 className="text-white font-heading font-semibold text-lg mb-1">Medical Billing & RCM Services</h3>
            <p className="text-gray-400 text-sm mb-5 font-body">Billing | Coding | AR | Credentialing</p>
            <Button variant="hero" className="w-full text-sm font-semibold font-heading">
              Get Quote for RCM
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;